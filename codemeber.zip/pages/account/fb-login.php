<?php
error_reporting(1);
ob_start();
session_start();
require '../../Core.php';
use Core\System;
$kun = new System;



require_once ('Facebook/autoload.php');

$fb = new Facebook\Facebook ([
  'app_id' => $kun->config('facebook_app_id'), // Id app
  'app_secret' => $kun->config('facebook_app_key'), // Mã bảo mật app
  'default_graph_version' => 'v3.0', //Giữ Nguyên
  ]);
$domain = $kun->config('home').'pages/account/fb-login.php';









$helper = $fb->getRedirectLoginHelper();
if (isset($_GET['state'])) {
    $helper->getPersistentDataHandler()->set('state', $_GET['state']);
}




try {
$accessToken = $helper->getAccessToken($domain);
//$accessToken = $helper->getAccessToken();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}
    




if (! isset($accessToken)) {
    
    $permissions = array('public_profile','email'); // Optional permissions
    $loginUrl = $helper->getLoginUrl($domain,$permissions);
    
    //echo'<pre>';
//echo $loginUrl;
//echo $domain;
    header("Location: ".$loginUrl);  
    //echo $loginUrl;
  exit;
}

try {
  // Returns a `Facebook\FacebookResponse` object
  $fields = array('id', 'name', 'email');
//  $response = $fb->get('/me?fields='.implode(',', $fields).'', $accessToken);
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}




$response = $fb->get('/me?fields=id,name,email,gender', $accessToken);
$fb_name = $response->getGraphUser()['name'];
$email = $response->getGraphUser()['email'];
$fb_id = $response->getGraphUser()['id'];
$sex = $response->getGraphUser()['sex'];


$time = time();

if($kun->check_user_fb_register($fb_id) == false) {


    $cmd = "INSERT INTO `users` (`uid`, `name`, `diemtichluy`, `money`, `money_nap`, `time`) VALUES ('".$fb_id."', '".$fb_name."', '0', '0', '0', '".$time."')";

    $res = mysqli_query($kun->connect_db(), $cmd);

    $_SESSION['username'] = $fb_id;
    $_SESSION['uid'] = $fb_id;
    $_SESSION['name'] = $fb_name;

}else {
    $_SESSION['username'] = $fb_id;
    $_SESSION['uid'] = $fb_id;
    $_SESSION['name'] = $fb_name;

}



      /* ---- vị trí header sau session ----*/
      header("Location: ".$kun->config('home')."home");




?>