<?php
namespace Core;

	
session_start();
error_reporting(1);
date_default_timezone_set("Asia/Bangkok");

$config = array(
'LOCALHOST' => 'localhost', // mysql host service
'USERNAME' => 'lmucetta_bacgau', // username
'PASSWORD' => 'lmucetta_bacgau', // pass
'DATABASE' => 'lmucetta_bacgau', // database

'home' => 'https://namlayloi.com/', // có https và có / ở cuối

'facebook_app_id' => '300477461301167', // fb app id
'facebook_app_key' => 'de1bb78e3ee383b7ca416c3d283eb104', // fb app key

'api_key' => '9856262f-4627-4488-bc88-4b3880de7ab3', // api ben Gachthe.Vn
'call_back' => 'https://'.$_SERVER['SERVER_NAME'].'/modun/napthe_callback.php' // CallBack Link - ko thay doi


);






class System {

   public function connect_db() {
        global $config;
    $conn = mysqli_connect($config['LOCALHOST'],$config['USERNAME'],$config['PASSWORD'],$config['DATABASE']) or die("Can't Connect To Database!");
    $conn->set_charset("utf8");
    return $conn;
    }


    public function __construct() {
        $this->connect_db();
    }


    public function config($option) {
        global $config;
        
                           return $config[$option];
    
    }




    public function anti_sql($number) {
$id = isset($number) ? (string)(int)$number : false;
$id = isset($number) ? $number : false;
$id = str_replace('/[^0-9]/', '', $id);
return $id;
    }


public function time_ago( $time )
{
    $time_difference = time() - $time;

    if( $time_difference < 1 ) { return 'vừa xong'; }
    $condition = array( 12 * 30 * 24 * 60 * 60 =>  'năm',
                30 * 24 * 60 * 60       =>  'tháng',
                24 * 60 * 60            =>  'ngày',
                60 * 60                 =>  'giờ',
                60                      =>  'phút',
                1                       =>  'giây'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $time_difference / $secs;

        if( $d >= 1 )
        {
            $t = round( $d );
            return $t . ' ' . $str . ( $t > 1 ? '' : '' ) . ' trước';
        }
    }
}


    public function count_user() {
        $result = mysqli_query($this->connect_db(), "SELECT `id` FROM `users`");
        $rowcount = mysqli_num_rows($result);
        return $rowcount;
    }




   public function check_user_fb_register($idfb) {

        $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$idfb."'");
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0) {
            return true;
        }else {
            return false;
        }
        
    }




    public function user() {

    $token = $_SESSION['username'];

    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$token."'");

    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

    return $row;

    }


    public function user_orther($username) {

    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$username."'");

    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

    return $row;

    }



// gọi Hàm này nếu như không muốn khách đã đăng nhập truy cập vào những trang như login, register bla bla 
public function check_login() {
    if($_SESSION['username']) {
        return header("Location: /home");
    }
}


public function check_rank() {

    $token = $_SESSION['username'];
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$token."'");
    $row = mysqli_fetch_array($result);

    $money = $row['money'] / 1000;

/*
20k = bạc
50k = vàng
100k = bạch kim
150k = kim cương 1
200k = kim cương 2
250k = kim cương 3
    */

    if($money < 20) {
        $rank = "Chưa Có";
    }else if($money >= 20 && $money < 50) {
        $rank = "Bạc";
    }else if($money >= 50 && $money < 100) {
        $rank = "Vàng";
    }else if($money >= 100 && $money < 150) {
        $rank = "Bạch Kim";
    }else if($money >= 150 && $money < 200) {
            $rank = "Kim Cương 1";
    }else if($money >= 200 && $money < 250) {
            $rank = "Kim Cương 2";
    }else if($money >= 250) {
            $rank = "Kim Cương 3";
    }else {
            $rank = "Bá Chủ Server";
    }

    return $rank;

}



public function check_rank_accept() {

    $token = $_SESSION['username'];
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$token."'");
    $row = mysqli_fetch_array($result);

    $money = $row['money_nap'] / 1000;

    if($money < 20) {
        $rank = "null";
    }else if($money >= 20 && $money < 50) {
        $rank = "bac";
    }else if($money >= 50 && $money < 100) {
        $rank = "vang";
    }else if($money >= 100 && $money < 150) {
        $rank = "bachkim";
    }else if($money >= 150 && $money < 200) {
            $rank = "kimcuong1";
    }else if($money >= 200 && $money < 250) {
            $rank = "kimcuong2";
    }else if($money >= 250) {
            $rank = "kimcuong3";
    }else {
            $rank = "Bạn Ngu Vãi Lồn";
    }

    return $rank;

}





public function check_percent() {

    $token = $_SESSION['username'];
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$token."'");
    $row = mysqli_fetch_array($result);

    $money = $row['money_nap'] / 1000;

/*
20k = bạc
50k = vàng
100k = bạch kim
150k = kim cương 1
200k = kim cương 2
250k = kim cương 3
    */

    if($money < 20) {
        $rank = 0;
    }else if($money >= 20 && $money < 50) {
        $rank = 16.6;
    }else if($money >= 50 && $money < 100) {
        $rank = 33.2;
    }else if($money >= 100 && $money < 150) {
        $rank = 49.8;
    }else if($money >= 150 && $money < 200) {
            $rank = 66.4;
    }else if($money >= 200 && $money < 250) {
            $rank = 83;
    }else if($money >= 250) {
            $rank = 100;
    }else {
            $rank = 100;
    }

    return $rank;
}



public function check_luot_quay() {

    $token = $_SESSION['username'];
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `uid`='".$token."'");
    $row = mysqli_fetch_array($result);

    $turn = $row['money'] / 20000;

    if($turn <= 0) return '0'; else return floor($turn);

}


public function check_qua_rank($rank, $item) {


                        switch ($item) {
                            case 1:
                                $gift = '400';
                             break;
                            case 2:
                                 $gift = '500'; 
                             break;
                            case 3:
                                 $gift = '4';
                             break;
                            case 4:
                                $gift = '14';
                             break;
                            case 5:
                                $gift = '14'; 
                             break;
                            case 6:
                                $gift = '4';
                             break;

                            case 7:
                                $gift = '1200';
                             break;

                            case 8:
                                $gift = '800';
                             break;
                
                        }



    switch ($rank) {
        case 'bac':
            $qua = $gift * 1;   
            break;
        case 'vang':
             $qua = $gift * 3;
            break;
        case 'bachkim':
             $qua = $gift * 4;
            break;
        case 'kimcuong1':
             $qua = $gift * 5;
            break;
        case 'kimcuong2':
             $qua = $gift * 6;
            break;
        case 'kimcuong3':
             $qua = $gift * 7;
            break;
        
    }


    return $qua;


}







    /***  chuyển đổi 0h:00 phút ngày hôm nay sang dạng timestamp    ***/
public function time_today() {

    $date = date('d-m-Y 00:00');
    $timestamp = strtotime($date);
    return $timestamp;

}



    /***   thống kê các hoạt động ngày hôm nay    ***/
public function thong_ke_today($type) {

  $hientai = time();
  $today = $this->time_today();

    switch ($type) {
        case 'user':
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `users` WHERE `time` > '".$today."' AND `time` < '".$hientai."' ");
    $row = mysqli_num_rows($result);
    return $row;
            break;

            case 'nap_the':
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `napthe` WHERE `time` > '".$today."' AND `time` < '".$hientai."' AND status = 'Thẻ Đúng'");

    $mon = 0;

    while ($row = mysqli_fetch_array($result)) {
        $mon = $mon + $row['amount'];
    }

    return $mon;
            break;

            case 'tong_the':
    $result = mysqli_query($this->connect_db(), "SELECT * FROM `napthe` WHERE `time` > '".$today."' AND `time` < '".$hientai."' AND status = 'Thẻ Đúng'");
    $row = mysqli_num_rows($result);
    return $row;
            break;

        

            case 'tong_doanh_thu':
    $result = mysqli_query($this->connect_db(), "SELECT * FROM napthe WHERE status = 'Thẻ Đúng'");
    $mon = 0;
    while ($row = mysqli_fetch_array($result)) {
        $mon = $mon + $row['amount'];
    }

    return $mon;
            break;


        default:
            return 'ERORR!!!';
            break;
    }



}








public function antil_text($text)
{
    $text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
     //$text=str_replace(" ","-", $text);
    //$text=str_replace("--","-", $text);
    //$text=str_replace("@","-",$text);
    //$text=str_replace("/","-",$text);
    //$text=str_replace("\\","-",$text);
    $text=str_replace(":","",$text);
    $text=str_replace("\"","",$text);
    $text=str_replace("'","",$text);
    $text=str_replace("<","",$text);
    $text=str_replace(">","",$text);
    $text=str_replace(",","",$text);
    $text=str_replace("?","",$text);
    $text=str_replace(";","",$text);
    $text=str_replace(".","",$text);
    $text=str_replace("[","",$text);
    $text=str_replace("]","",$text);
    $text=str_replace("(","",$text);
    $text=str_replace(")","",$text);
    $text=str_replace("́","", $text);
    $text=str_replace("̀","", $text);
    $text=str_replace("̃","", $text);
    $text=str_replace("̣","", $text);
    $text=str_replace("̉","", $text);
    $text=str_replace("*","",$text);
    $text=str_replace("!","",$text);
    //$text=str_replace("$","-",$text);
    //$text=str_replace("&","-and-",$text);
    $text=str_replace("%","",$text);
    $text=str_replace("#","",$text);
    $text=str_replace("^","",$text);
    $text=str_replace("=","",$text);
    $text=str_replace("+","",$text);
    $text=str_replace("~","",$text);
    $text=str_replace("`","",$text);
    //$text=str_replace("--","-",$text);
    $text=strtolower($text);
    return $text;
}



public function tim_chuoi($str, $chuoi) {

 if (strpos($str, $chuoi) !== false) {
 return true;
}else {
 return false;
}


}


public function gio($gio){
$time=time();
$jun=round(($time-$gio)/60);
if($jun<1){$jun='Vừa xong';}
if($jun>=1 && $jun<60){$jun="$jun phút trước";}
if($jun>=60 && $jun<1440){$jun=round($jun/60); $jun="$jun giờ trước";}
if($jun>=1440){$jun=round($jun/60/24); $jun="$jun ngày trước";}
return $jun;
}



function is_mobile() {
    if ( empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
        $is_mobile = false;
    } elseif ( strpos( $_SERVER['HTTP_USER_AGENT'], 'Mobile' ) !== false // many mobile devices (all iPhone, iPad, etc.)
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'Android' ) !== false
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'Silk/' ) !== false
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'Kindle' ) !== false
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'BlackBerry' ) !== false
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'Opera Mini' ) !== false
        || strpos( $_SERVER['HTTP_USER_AGENT'], 'Opera Mobi' ) !== false ) {
            $is_mobile = true;
    } else {
        $is_mobile = false;
    }

    return $is_mobile;
}



} // End Class


