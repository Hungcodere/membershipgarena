<?php
require '../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();


$res = mysqli_query($kun->connect_db(), "SELECT * FROM `lichsuquay` WHERE `uid`='".$user['uid']."'");

$i = 1;
while ($row = mysqli_fetch_array($res)) {
	
	?>
	<tr>
		<td>#<?php echo $i;?></td>
		<td><?php echo $row['gift'];?></td>
		<td><?php echo date('H:i d/m', $row['time']);?></td>
		<td><?php echo $row['status'];?></td>
	</tr>

<?
$i++;
}
?>