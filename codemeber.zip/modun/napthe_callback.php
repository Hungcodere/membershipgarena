<?php
require '../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();


$myfile = fopen("log/log.txt", "a");
$txt = $_GET['Code']."|".$_GET['Mess']."|".number_format($_GET['CardValue'])."|".$_GET['TrxID']."\n";
fwrite($myfile, $txt);
fclose($myfile);




if($_GET['Code']) {
	    
			$code = $_GET['Code'];
			$tranid = $_GET['TrxID'];

			$resq = mysqli_query($kun->connect_db(), "SELECT * FROM `napthe` WHERE `tranid` = '".$tranid."' ");

			$get = mysqli_fetch_array($resq);
   
 			$money = $get['amount'];


					if ($code == 1) {

	 mysqli_query($kun->connect_db(), "UPDATE `users` SET `money` = `money` + '".$money."' WHERE `uid` = '".$get['username']."' ");
	 mysqli_query($kun->connect_db(), "UPDATE `users` SET `money_nap` = `money_nap` + '".$money."' WHERE `uid` = '".$get['username']."' ");
	 mysqli_query($kun->connect_db(), "UPDATE `users` SET `diemtichluy` = `diemtichluy` + '5' WHERE `uid` = '".$get['username']."' ");

 	 mysqli_query($kun->connect_db(), "UPDATE `napthe` SET `status` = 'Thẻ Đúng' WHERE `tranid`='".$tranid."'");   


    } else if ($code == 5) {

 	 mysqli_query($kun->connect_db(), "UPDATE `napthe` SET `status` = 'Chờ Duyệt' WHERE `tranid`='".$tranid."'");   	

	} else if ($code == 2) {

 	 mysqli_query($kun->connect_db(), "UPDATE `napthe` SET `status` = 'Thẻ Sai' WHERE `tranid`='".$tranid."'");   

        }else{
						
						echo $_GET['Mess']; 

					}


				}