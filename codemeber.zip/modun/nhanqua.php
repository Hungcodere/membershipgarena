<?php
sleep(1);

require '../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();
echo $user['uid'];

mysqli_query($kun->connect_db(), "UPDATE `users` SET `diemtichluy`='0' WHERE `uid`='".$user['uid']."'");