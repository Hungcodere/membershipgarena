<?php
require '../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();

function curl_post($url = null, $header = [])
    {
        if (!empty($url)) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            if (curl_errno($ch)) {
                $res = "Lỗi: " . curl_error($ch);
            } else {
                $res = curl_exec($ch);
            }
            curl_close($ch);
            return $res;
        }
    }


    if (!isset($_POST['type']) || !isset($_POST['serial']) || !isset($_POST['pin'])) {
        die('Bạn cần nhập đầy đủ thông tin');
    } else {

        $type = $_POST['type'];
        $serial = $_POST['serial'];
        $pin = $_POST['pin'];
        $amount = $_POST['amount'];

        $kiemtra = mysqli_query($kun->connect_db(), "SELECT COUNT(*) FROM napthe WHERE pin = '".$pin."' AND serial = '".$serial."'");
        $check = mysqli_num_rows($result);


        $sotiendung = '<span class="c-font-bold text-info">+'.number_format($amount).'đ</span>';
        $sodudung = $user['money'] + $amount;
        $motadung = 'Nạp thẻ '.$type.' '.number_format($amount).'đ';

        if ($check > 0) {
            die('Thẻ này đã tồn tại trên hệ thống');
        }  else {



$tranid = rand(10000, 99999);  /// Cái này có thể mà mã order của bạn, nó là duy nhất (enique) để phân biệt giao dịch.
$network = $type;

$api_key = $kun->config('api_key');
$call_back = $kun->config('call_back');

$api = 'http://gachthe.vn/API/NapThe?APIKey='.$api_key.'&Network='.$network.'&CardCode='.$pin.'&CardSeri='.$serial.'&CardValue='.$amount.'&URLCallback='.$call_back.'&TrxID='.$tranid;


$post = json_decode(curl_post($api), true);
                    
                    // {"Code":1,"Message":"Đã nhận thẻ"}

                   if ($post['Code'] == 1) {

   $cmd = "INSERT INTO napthe SET username = '".$user['uid']."', pin = '".$pin."',serial = '".$serial."', type = '".$type."', amount = '".$amount."', tranid = '".$tranid."', status = '3',time = '".time()."'";

   mysqli_query($kun->connect_db(), $cmd);


    die('Thẻ '.$type.' mệnh giá '.number_format($amount).'đ đã được lưu vào hệ thống thành công! Vui lòng chờ duyệt thẻ trong 30s - 2 phút');


                    }else{
                          die($post['Message']);
                    }

        }
    }

