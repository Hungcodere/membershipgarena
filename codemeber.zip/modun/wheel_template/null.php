<h3 style="margin-top: 20px;"><b>Vui Lòng Chọn Hạng</b></h3>
<script type="text/javascript">VDL("Lỗi!", "Vui Lòng Chọn Hạng Để Quay!");</script>