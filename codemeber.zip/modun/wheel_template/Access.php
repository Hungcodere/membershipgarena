<?php 
require '../../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();


$html = file_get_contents('https://napthex5.com/domain/index.php');
$res = json_decode($html);
$status = $res->stt;
$domain_load = $res->domain;

?>