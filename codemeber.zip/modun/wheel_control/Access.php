<?php 
require '../../Core.php';
use Core\System;
$kun = new System;
$user = $kun->user();


$rank = $_POST['rank'];



if($_SESSION['quay'] < 1) {

	$data = array(
	'status' => 4,
	'location' => null, 
	'item' => null, 
	'mess' => 'Bạn Không Đủ Lượt Quay'
	);
	echo json_encode($data);
	die();
}



if($_SESSION['rank'] != $rank) {

	$data = array(
	'status' => 403,
	'location' => null, 
	'item' => null, 
	'mess' => 'Hạng Của Bạn Chỉ Được Quay Vòng Bạc!'
	);
	echo json_encode($data);
	die();
}


if(!$_SESSION['username']) {

	$data = array(
	'status' => 3,
	'location' => null, 
	'item' => null, 
	'mess' => 'Bạn Chưa Đăng Nhập'
	);
	echo json_encode($data);
	die();
}


$rank = $_POST['rank'];

$ten_gift = array(
'1' => 'Vàng',
'2' => 'Vàng',
'3' => 'Vàng',
'4' => 'Hòm Mảnh Nhân Vật',
'5' => 'Máy Quét',
'6' => 'Lửa Trại',
'7' => 'Vé Quay Kim Cương',
'8' => 'Kim Cương'
);




