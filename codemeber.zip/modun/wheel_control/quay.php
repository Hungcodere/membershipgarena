<?php

require("Access.php");

require("BiasedRandom/Element.php");
require("BiasedRandom/Randomizer.php");

  $randomizer = new Randomizer();
  
  $randomizer          ->add( new Element('1', 14)) 
                       ->add( new Element('2', 14)) 
                       ->add( new Element('3', 14))
                       ->add( new Element('4', 14)) 
                       ->add( new Element('5', 14))
                       ->add( new Element('6', 14)) 
                       ->add( new Element('7', 14)) 
                       ->add( new Element('8', 80)) 
                          ;
            $kundeptrai = $randomizer->get();      

switch ($kundeptrai) {
    case '8':
    $vongquay = 8;
    $location = 40;        
        break;
    case '7':
    $vongquay = 7;
    $location = 80;        
        break;
    case '6':
    $vongquay = 6;
    $location = 120;        
        break;
    case '5':
    $vongquay = 5;
    $location = 173;       
        break;
    case '4':
    $vongquay = 4;
    $location = 230;        
        break;
    case '3':
    $vongquay = 3;
    $location = 270;        
        break;
    case '2':
    $vongquay = 2;
    $location = 330;        
        break;
    case '1':
    $vongquay = 1;
    $location = 356;
        break;

}


$gia_tri = $kun->check_qua_rank($rank, $kundeptrai);


$_SESSION['quay'] = 0;


$data = array(
'status' => 1,
'location' => $location, 
'item' => $vongquay, 
'mess' => 'Bạn nhận được '.$ten_gift[$vongquay].' x'.$gia_tri
);

echo json_encode($data);